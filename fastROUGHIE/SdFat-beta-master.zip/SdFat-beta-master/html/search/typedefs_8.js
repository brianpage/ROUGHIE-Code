var searchData=
[
  ['spidefault_5ft',['SpiDefault_t',['../_sd_spi_8h.html#a312d9e68dd648980324728cc06d3bf6a',1,'SdSpi.h']]],
  ['streamsize',['streamsize',['../classios__base.html#a82836e1d3cc603fba8f0b54d323a2dff',1,'ios_base']]]
];
